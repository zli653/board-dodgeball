#helper function
uint8_t get_x_block(uint16_t x_pos) {

}

uint16_t get_block_center(uint8_t block_num) {
	 
}